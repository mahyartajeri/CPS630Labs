# How to run php
rename php file to index.php

run `php -S 127.0.0.1:8000`

go to http://localhost:8000/